# duns-cli

A read-first, approval-gated CLI for analyzing and safely evolving database schemas around **DUNS** (Data Universal Numbering System) columns — expansion, DDL changes, and downstream data migration — with full impact analysis before anything is written.

> ⚠️ **No write operation ever executes without explicit manual approval.** This tool is designed to be conservative by default: it reads, analyzes, and proposes — it does not act — until you say yes.

---

## Why this exists

DUNS-related columns (`DUNS`, `%DUNS%`, `PARENT_DUNS`, `DUNS_NUM`, etc.) tend to be scattered across many tables, views, and stored procedures, often with inconsistent types and widths (e.g. `VARCHAR(9)` vs `VARCHAR(13)` for the newer 13-digit format). Expanding or refactoring these columns by hand is risky — a missed dependency (an SP, a FK, a view, a trigger) can silently break downstream systems.

`duns-cli` gives you:

- A **single source of truth** for what the schema currently looks like (cached locally, refreshable on demand).
- **Automatic discovery** of every DUNS-like column, table, and dependent object (SPs, views, triggers, FKs, indexes).
- **Impact analysis** for any proposed change before it's applied.
- A **hard approval gate** — nothing touches the database until you review and confirm.

---

## Core workflow

```
┌──────────────────┐     ┌────────────────────┐     ┌─────────────────────┐
│ 1. Schema Source   │ →  │ 2. Discover DUNS    │ →  │ 3. Propose Change    │
│ (live DB or cache) │     │ objects & lineage   │     │ (DDL / migration)   │
└──────────────────┘     └────────────────────┘     └─────────────────────┘
                                                              │
                                                              ▼
                                             ┌─────────────────────────────┐
                                             │ 4. Impact Analysis Report   │
                                             │ (tables, SPs, views, FKs,   │
                                             │  data volume, downtime)     │
                                             └─────────────────────────────┘
                                                              │
                                                              ▼
                                             ┌─────────────────────────────┐
                                             │ 5. Manual Approval (required)│
                                             └─────────────────────────────┘
                                                              │
                                                              ▼
                                             ┌─────────────────────────────┐
                                             │ 6. Execute (transactional,  │
                                             │    logged, reversible)      │
                                             └─────────────────────────────┘
```

### 1. Schema source: live query or cached copy

On startup (or on demand), the CLI asks:

```
? Schema for this session:
  ❯ Use cached schema snapshot (fast, may be stale)
    Query the database now and refresh the cache
    Query the database now, don't update the cache
```

- The cache is a versioned, timestamped local copy of schema metadata (tables, columns, types, constraints, indexes, SP/view definitions).
- You're prompted every session (or every N minutes — configurable) rather than the tool silently trusting a stale cache or hammering the database unnecessarily.
- Cache diffs are shown when a refresh reveals drift from the last snapshot.

### 2. DUNS object discovery

The CLI scans the schema (live or cached) for anything matching your configured DUNS pattern set, e.g.:

- Column names matching `%DUNS%`, `%DUN%` (configurable, case-insensitive)
- Known aliases you register (e.g. `BUS_ID`, `VENDOR_NUM`) if they're functionally DUNS fields
- Data-shape heuristics (9 or 13-digit numeric strings) as a secondary signal, flagged separately from name matches

Output includes the table, column, current type/width, nullability, and every dependent object referencing it.

### 3. Propose a change

Changes are requested in plain language or structured flags — e.g. "expand all DUNS columns to VARCHAR(13)" or "add PARENT_DUNS to table X." The CLI translates this into a concrete DDL/migration plan (never executes it yet).

### 4. Impact analysis

Before any plan is eligible for approval, the CLI produces a report covering:

- **Direct impact**: tables/columns being altered, current vs. proposed definition
- **Dependent objects**: stored procedures, views, triggers, functions referencing the column(s)
- **Referential integrity**: foreign keys, indexes, unique constraints affected
- **Data impact**: row counts, potential truncation/precision-loss risk, sample of at-risk rows
- **Downstream consumers**: known jobs/ETL/reports referencing the object (where discoverable)
- **Estimated blast radius**: number of objects touched, rough lock/downtime risk for the target engine

The report is saved to disk (and printed) so it can be reviewed, shared, or attached to a change ticket.

### 5. Manual approval — non-negotiable

- Every plan requires an explicit `approve` step with a typed confirmation (e.g. re-typing the object name or plan ID).
- Approval is scoped to **one plan, one execution**. Nothing is auto-approved, batched, or replayed silently.
- All approvals/rejections are logged with who, when, and the exact plan hash that was approved.

### 6. Execution

- Runs inside a transaction where the engine supports DDL transactions; otherwise runs a pre-flight dry run plus a scripted rollback path.
- Every execution is logged (statement-by-statement) to an audit trail.
- On failure, the CLI stops and reports exactly what did/didn't apply — it does not attempt automatic retries on write operations.

---

## Features

- 🔍 **Read-only by default** — every command is safe to run against production unless it's explicitly a `plan apply` step.
- 🗂️ **Local schema cache** with versioned snapshots and diffing.
- 🎯 **DUNS-aware discovery** via configurable name/pattern matching.
- 📊 **Impact analysis reports** (console, Markdown, or JSON for CI/ticketing integration).
- 🔐 **Hard approval gate** before any write, with typed confirmation and audit logging.
- 🧩 **Stored procedure awareness** — flags SPs that reference impacted tables/columns, including via dynamic SQL where detectable.
- ↩️ **Rollback plans** generated alongside every forward migration plan.
- 🧾 **Full audit log** of every read, plan, approval, and execution.

---

## Installation

```bash
# via pip
pip install duns-cli

# or from source
git clone https://github.com/your-org/duns-cli.git
cd duns-cli
pip install -e .
```

## Configuration

Create a `duns-cli.config.yaml` in your project root (or point to one with `--config`):

```yaml
database:
  engine: postgres        # postgres | mysql | mssql | oracle
  connection_env: DUNS_CLI_DB_URL   # never store credentials in this file

schema_cache:
  path: .duns-cli/schema-cache.json
  prompt_on_startup: true
  auto_stale_after_minutes: 1440    # nudge to refresh after 24h

duns_patterns:
  columns:
    - "%DUNS%"
    - "%DUN%"
  aliases:
    - "BUS_ID"
    - "VENDOR_NUM"

approval:
  require_typed_confirmation: true
  audit_log_path: .duns-cli/audit.log

execution:
  dry_run_default: true
  transactional_ddl: true
```

Credentials are always read from environment variables or a secrets manager — never from the config file.

---

## Usage

```bash
# Point the CLI at your database (or reuse the cache)
duns-cli schema sync                    # refresh the local schema cache
duns-cli schema status                  # show cache freshness / drift

# Discover DUNS-related objects
duns-cli duns discover                  # list all matching columns/tables
duns-cli duns discover --table CUSTOMERS

# Analyze a proposed change without applying anything
duns-cli plan create --describe "expand DUNS columns to VARCHAR(13)"
duns-cli plan show <plan-id>
duns-cli plan impact <plan-id>          # full impact analysis report
duns-cli plan impact <plan-id> --format markdown > impact-report.md

# Review dependent stored procedures / views
duns-cli deps show --column CUSTOMERS.DUNS_NUM

# Approve and apply (the only commands that can write)
duns-cli plan approve <plan-id>
duns-cli plan apply <plan-id> --dry-run     # simulate, still no writes
duns-cli plan apply <plan-id>               # requires prior approval

# Undo
duns-cli plan rollback <plan-id>

# Audit trail
duns-cli audit log
duns-cli audit show <plan-id>
```

---

## Safety guarantees

| Guarantee | How it's enforced |
|---|---|
| No silent writes | `plan apply` refuses to run without a matching `plan approve` record |
| No stale-cache surprises | Session prompt + configurable staleness warning |
| No missed dependencies | Discovery walks FKs, indexes, views, triggers, and SP bodies |
| No unreviewable changes | Every plan has a human-readable + JSON impact report |
| No untraceable actions | Every read/plan/approve/apply is appended to `audit.log` |

---

## Roadmap

- [ ] Support for cross-database DUNS consistency checks (e.g. same column, different width across replicas/shards)
- [ ] CI integration mode (`plan impact --format json` as a PR check)
- [ ] Pluggable naming-pattern packs beyond DUNS (generic "regulated identifier expansion" mode)

## Contributing

Issues and PRs welcome — please include a sample (anonymized) schema snippet when reporting discovery/impact-analysis bugs, since most issues are pattern-matching or dependency-detection edge cases.

## License

MIT (or your org's preferred license — update before publishing).

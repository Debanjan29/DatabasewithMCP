# Strict Review & Safe Execution Policy

## 1. Core Rule

**Never change any settings, execute any code, or modify any data without explicit prior user review and approval.**

**All database write operations must be explicitly transaction-wrapped (`BEGIN TRANSACTION ... COMMIT/ROLLBACK`), never relying on implicit/automatic transaction handling from any tool.**

**The MCP connection available to the agent is read-only by construction (see Section 6) — the agent has no tool capable of writing to the database under any circumstance.** All writes are drafted by the agent and executed exclusively by the user.

---

## 2. Prohibited Autonomous Actions

The following must **never** be performed without explicit prior approval:

- **Role/Privilege changes** — no `ALTER ROLE`, `CREATE ROLE`, `DROP ROLE`, `GRANT`, or `REVOKE`.
- **Unreviewed DML/DDL** — no `INSERT`, `UPDATE`, `DELETE`, `DROP`, `CREATE`, or `ALTER TABLE` without first presenting the exact SQL for review.
- **No execution of any kind via MCP** — the MCP connection is read-only by construction (Section 6). No write statement is ever sent through it, regardless of how minor, how urgent, or how clearly approved the change is. Approved writes are handed to the user as a script; they are never executed by the agent through any tool.
- **Reliance on implicit transaction wrapping** — every write must be inside an explicit, manually controlled transaction (see Section 4).
- **Settings & credentials** — no autonomous edits to `.env` files, connection strings, or system configuration without confirmation.
- **Arbitrary code/terminal execution** — no scripts or shell commands run silently without upfront explanation and review.

### Comment handling
Never read, extract, or act on values from commented-out lines (`#`, `//`, `/*`, `--`) in `.env` or configuration files. Only active, uncommented entries are considered valid.

---

## 3. Batching Rule

- Default maximum batch size: **10,000 rows** per commit.
- This limit may only be exceeded if the user explicitly states so within the session, or updates this file directly to change the default. No autonomous override, regardless of table size or perceived low risk.
- Large migrations must be broken into batches using a pattern such as `UPDATE TOP (n) ... ` in a loop, with a separate commit per batch, and a checkpoint/progress marker so the migration is resumable if interrupted.

### Batch processing for multi-million-row tables

DUNS-related tables on a production system may run into the millions of rows. For these, batching isn't just a size limit — it needs the same discipline any large-scale migration requires:

- **Batch on a narrow, indexed key**, not an unindexed predicate — batching by clustered key range (e.g. `WHERE CUST_ID > @last_key`) keeps each batch's scan cheap and predictable; batching purely on `WHERE new_DUNS IS NULL` without a supporting index degrades as the migration progresses and the "already done" portion grows.
- **Monitor transaction log growth**, especially under the FULL recovery model — many small batches with individual commits (as required here) keep this manageable by design, but a very large migration is still worth flagging to the user as something to watch, particularly if log backups aren't running frequently on this database.
- **Prefer off-peak execution** for large multi-million-row tables — this should be called out explicitly in the plan presented at Phase A as a recommendation, not assumed or silently scheduled, since the user is the one who knows the client's actual traffic patterns.
- **Expect and design for interruption** — at this scale, a batch loop running for hours will encounter at least one connection drop, deadlock, or interruption in practice. The checkpoint mechanism (Section 3a) exists specifically for this, not as a theoretical safeguard.
- **Re-check estimated scale before committing to a batch plan** — if the dry run's estimate (Section 5) is significantly larger than expected, that's a signal to revisit batch size, scheduling, and whether this table needs its own dedicated maintenance window rather than proceeding on the original assumption.

### 3a. Checkpoint & Resume Handling (Data Migration only)

This applies specifically to column-to-column **data migration** batch loops. Single-statement DDL (adding a column, a future rename) does not need this — it isn't a long-running batch process.

**Checkpoint storage — database, not a file**
- Progress is tracked in a dedicated table, `duns_cli.migration_checkpoint`, created once via its own approved plan (see below) — not auto-created on first use.
- The checkpoint update statement for a batch is included **inside the same script the user runs for that batch**, positioned so it commits or rolls back atomically with the batch's data write in the user's own transaction — this is why the checkpoint lives in the database rather than a local file. The agent drafts this statement; it does not execute it.

```sql
CREATE TABLE duns_cli.migration_checkpoint (
    plan_id               VARCHAR(50)  NOT NULL,
    table_name            SYSNAME      NOT NULL,
    phase                 VARCHAR(20)  NOT NULL DEFAULT 'data_migration',
    last_processed_key    BIGINT       NULL,
    rows_completed         BIGINT      NOT NULL DEFAULT 0,
    estimated_total_rows  BIGINT       NULL,
    status                 VARCHAR(20) NOT NULL DEFAULT 'in_progress',  -- in_progress | completed | failed
    started_at            DATETIME2    NOT NULL DEFAULT SYSUTCDATETIME(),
    last_updated_at       DATETIME2    NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_migration_checkpoint PRIMARY KEY (plan_id, table_name)
);
```

- **Creating this table is itself a write operation** and goes through a normal Phase A/B approval cycle — a one-time setup plan, reused by every future migration plan afterward. It is never silently auto-created.

**Local workspace mirror — for fast inspection, not authoritative**
- After each batch commits, the current checkpoint state is also written to a local JSON file under `.duns-cli/checkpoints/`, purely so progress and failure history can be inspected quickly without querying the database.
- This file also holds structured **failure details** per batch (timestamp, error, what action was taken) — easier to scan than digging through the log file for the same information.
- If the local mirror and the database checkpoint ever disagree, **the database checkpoint wins** — the mirror is a convenience cache, never the source of truth.

```json
{
  "plan_id": "PLAN-2026-0142",
  "table": "dbo.CUSTOMERS",
  "last_processed_key": 640000,
  "rows_completed": 640000,
  "estimated_total_rows": 812000,
  "status": "in_progress",
  "last_synced_from_db_at": "2026-08-16T14:41:10Z",
  "failures": [
    {
      "batch_number": 42,
      "timestamp": "2026-08-16T14:22:03Z",
      "error": "Deadlock victim (error 1205)",
      "action_taken": "ROLLBACK TRANSACTION; batch retried and succeeded at 14:23:10"
    }
  ]
}
```

**On resume — checked read-only against the database, not the local mirror**
- Before drafting the next batch's script, the agent checks `duns_cli.migration_checkpoint` read-only for this plan/table. If a checkpoint exists in `in_progress` or `failed` state, surface it as part of the guardrail summary handed to the user (Section 4), and present an explicit choice — never inferred:
  - **Resume** (default shown) — continue from `last_processed_key`.
  - **Restart** — reprocess from the beginning. Safe only because every batch predicate is required to be idempotent (see below); still requires its own explicit confirmation.
  - **Abort** — leave the checkpoint untouched, exit.

**Idempotency — the requirement that makes Restart safe**
- Every batch predicate must be written so that re-running it doesn't double-apply (e.g. only touching rows where the target column is still unmigrated). This is a constraint on how every Phase 2 migration script is drafted, not an optional nicety — it's the only reason "Restart" can ever be offered as a safe option.

**Commit/rollback remains manual**
- Each batch's commit is decided and typed by the user themselves, in their own session, after reviewing that batch's verification output (Section 4a). This checkpoint design doesn't change that — it only makes each batch resumable/traceable. (This per-batch cadence can be revisited later if it proves impractical at scale — noted as an open design question, not settled here.)

---

## 4. Transaction Flow (Two-Phase)

**Execution is manual-only.** The MCP connection used by the agent is read-only (see Section 6) — it cannot run `BEGIN TRANSACTION`, DDL, DML, `COMMIT`, or `ROLLBACK` under any circumstance, by construction, not just by policy. All writes are drafted by the agent and executed by the user themselves, typically via SSMS.

### Phase A — Draft & Approve (agent's work, entirely read-only)
1. Draft the exact SQL script (DDL/DML), fully transaction-wrapped and batched per Section 3, ending with the transaction left open on `COMMIT`/`ROLLBACK` for the user to decide themselves once they've reviewed the output in their own session (see Phase B).
2. Generate the corresponding rollback script alongside it.
3. Run a **dry run** (see Section 5) — a real, live `SELECT` executed through the read-only MCP connection, no transaction, no lock.
4. If the plan requires a recovery snapshot (Section 4b) or a checkpoint table (Section 3a), include their creation statements as part of the script bundle — these are writes too, and are executed by the user in the same manual pass, never by the agent.
5. Present together for review: the exact SQL script (including any snapshot/checkpoint statements), the dry-run output, and the rollback script.
6. **STOP.** Wait for explicit approval before handing over the final script bundle.

### Phase B — Manual Execution (the only execution path)

1. Once approved, the agent hands over the complete script bundle — snapshot/checkpoint setup (if applicable), the transaction-wrapped DDL/DML, and the verification queries — along with the pre-execution guardrail summary (below) for the user to check against the approved plan themselves.
2. The user runs it themselves, in their own SSMS (or equivalent) session:
   - `BEGIN TRANSACTION; SET XACT_ABORT ON;`
   - The approved DDL/DML
   - The included verification `SELECT`s (Section 4a), reviewed by the user directly in their own session against the uncommitted state
   - Only then, `COMMIT TRANSACTION;` or `ROLLBACK TRANSACTION;`, typed by the user themselves
3. **The agent is not present for this decision and does not send `COMMIT`/`ROLLBACK` on the user's behalf** — it has no connection capable of doing so. The pause-and-review property is preserved entirely within the user's own session, not mediated by the agent.
4. Once the user reports the outcome (or the agent independently checks, per step 5), the agent records `COMMITTED`, `ROLLED BACK`, or `UNKNOWN — pending user confirmation` in the log file, never assuming success silently.
5. **Post-execution verification (read-only, agent-performed):** after the user confirms execution, the agent re-queries the live table via the read-only MCP connection — schema metadata, row samples, checkpoint state — and compares it against what Phase A approved. This is the one verification step the agent *can* perform directly, since it's read-only, and it happens after the fact rather than inside an open transaction the agent doesn't hold.

#### Pre-execution guardrail (informational — included with the script bundle, not enforced by the agent)

Since the agent cannot gate execution itself, this is delivered as part of the handed-over bundle for the user to check before they run anything:

```
==================================================================
 TARGET CONFIRMATION — CHECK BEFORE YOU RUN THIS
------------------------------------------------------------------
 Server:            SQLPROD01.client.local
 Database:          ClientDB_Production
 Environment:        PRODUCTION
 Major table(s):     dbo.CUSTOMERS
 Minor table(s):     dbo.PARENT_LOOKUP (FK child)
                      dbo.CUSTOMER_SUMMARY_VW (view dependency)
                      dbo.sp_GetCustomerDuns (SP dependency)
 Recovery snapshot:   ClientDB_Production_snap_PLAN-2026-0142 (create statement included below, per Section 4b)
------------------------------------------------------------------
 Confirm this matches the approved plan before running the script.
==================================================================
```

- "Major table(s)" = the table(s) directly altered by the approved plan.
- "Minor table(s)" = every dependent object surfaced by the Dependency Discovery Procedure (Section 7) for the affected column(s).
- Server/database/environment values here come from what the agent could determine read-only (e.g. `SELECT @@SERVERNAME, DB_NAME()`) via the MCP connection during Phase A — the agent surfaces this so the user can catch a wrong-environment mistake themselves, but cannot block execution the way a held-open session could.

#### Log file

- Path: `.duns-cli/logs/<plan-id>_<YYYYMMDD_HHMMSS>.log`
- Contains the approved script bundle, the guardrail summary, and — once known — the outcome (`COMMITTED`/`ROLLED BACK`/`UNKNOWN`) plus the agent's post-execution verification results (Section 4a).
- For data migration batches (Section 3a), each batch's outcome and checkpoint state is appended as it becomes known to the agent (via user report or post-execution read-only check), e.g.:
  `[BATCH 64] rows 630,001–640,000 — COMMITTED (user-confirmed) — checkpoint (verified read-only): last_key=640000, rows_completed=640,000/~812,000 (est.)`
- One log file per execution attempt — never overwritten or appended across separate runs, so the audit trail stays per-attempt.

## 4a. Verification

Verification happens in two parts, split by who can actually perform it:

**Inside the transaction (run by the user, in their own session)**
The verification `SELECT`s are included in the script bundle handed to the user, positioned between the DDL/DML and the `COMMIT`/`ROLLBACK` line, so the user sees this output themselves before deciding:
- **Row count check** — actual rows affected in this batch vs. the optimizer's estimated row count from the dry run (Section 5); a sanity comparison against an estimate, not an exact figure — order-of-magnitude mismatches matter, small deltas don't.
- **Data spot-check** — a small sample (5–20 rows) of before/after values shown directly, not just a pass/fail count.
- **NULL/boundary check** — unexpected NULLs, or values that still appear truncated/malformed after the change.
- **Constraint sanity check** — confirms no constraint was silently bypassed.
- **Schema metadata check** (DDL only) — re-queries `sys.columns` inside the transaction to confirm the live definition now matches what was approved in Phase A.

**After commit (run by the agent, read-only, via MCP)**
Once the user confirms the transaction was committed, the agent independently re-verifies using its read-only connection — the same checks, run again against the now-committed state:
- Re-confirm the schema/data matches what Phase A approved.
- Re-check the checkpoint table's state (Section 3a), if applicable.
- Record the result in the log file, distinct from what the user reported — so any mismatch between "user said committed" and "agent's own read-only check" is caught and surfaced, not assumed consistent.

## 4b. Pre-Execution Recovery Snapshot

A database-level recovery point is created as part of the same manually-executed script bundle — the agent cannot create it directly, since `CREATE DATABASE ... AS SNAPSHOT OF` is itself a write.

- **Included in the approved script bundle, not a separate silent action.** The Phase A plan explicitly includes the snapshot-creation statement as the first step in the script the user will run. Approving the plan approves this step along with it.
- **Check-before-include (read-only, agent-performed).** Before drafting the plan, the agent checks `sys.databases` (read-only) for an existing snapshot matching this `plan_id`. If one already exists, the agent omits a duplicate creation statement and references the existing snapshot by name instead. Only if none exists does the script bundle include the `CREATE DATABASE ... AS SNAPSHOT` statement.
- **Mechanism — native database snapshot**, fast and cheap (copy-on-write, near-instant creation, grows only as data changes afterward):

```sql
CREATE DATABASE <db>_snap_<plan_id>
ON (NAME = <db>, FILENAME = 'D:\Snapshots\<db>_snap_<plan_id>.ss')
AS SNAPSHOT OF <db>;
```

- **The user runs this statement themselves**, as the first part of the approved script bundle, before the `BEGIN TRANSACTION` for the actual change.
- **Log the snapshot name.** Once the user confirms the snapshot statement ran, the agent records it in the plan record and log file, so the revert path (`RESTORE DATABASE <db> FROM DATABASE_SNAPSHOT = '<snapshot_name>'`) always references a specific, known recovery point.
- **Known limitation, stated plainly rather than silently assumed away:** a database snapshot lives on the same instance/disk as the live database — it protects against a bad migration, not against disk/instance failure. It is the default recovery point for this framework's revert needs, not a substitute for the client's own off-box backup strategy.
- **Edition/feature availability isn't assumed.** The agent should check for native snapshot support (read-only, via edition metadata) during Phase A rather than silently including an unsupported statement — if unsupported, the plan calls out that confirming a recent full backup exists is a manual prerequisite instead.

## 4c. Table-Level Backup Table (`_bkt`) — Required Before DUNS Expansion

In addition to the database-level snapshot (Section 4b), every table undergoing DUNS expansion requires its own **table-level backup copy**, using the naming convention `<table>_bkt`. This is a separate, complementary safeguard — a database snapshot protects the whole database and is fast to create, but a dedicated backup table is easy to query directly, survives independently of snapshot lifecycle/reversion, and gives a simple, obvious place to compare against later without restoring anything.

- **Check first (read-only).** Before drafting a Phase 2 migration plan for a table, the agent checks whether `<table>_bkt` already exists (e.g. `dbo.CUSTOMERS_bkt`). This is a plain metadata/existence check via the read-only connection.
- **If it doesn't exist, its creation is included in the approved script bundle**, as a step the user runs before the migration batches begin — not created silently, and not assumed to already be there:

```sql
SELECT *
INTO dbo.CUSTOMERS_bkt
FROM dbo.CUSTOMERS;
```

- **If it already exists**, the agent does not overwrite or recreate it by default — an existing `_bkt` table is treated as an intentional prior backup. Refreshing it (if the user wants a more current copy) is its own explicit decision, called out to the user rather than assumed.
- **This check is a hard prerequisite for Phase 2 (data migration) on any DUNS-affected table** — migration batches for a table should not be proposed until the corresponding `_bkt` table is confirmed to exist (either pre-existing or created as part of the approved plan).
- **Scope note**: this convention applies specifically to tables undergoing DUNS expansion/migration (per `03_DUNS_MIGRATION_LIFECYCLE.md`), not to every table the tool touches — Phase 1 (adding a nullable column) doesn't require it, since no existing data is altered at that stage.

---

## 5. Dry Run

- Before Phase A approval, generate a read-only preview using the **same predicate/logic** as the real write (same `WHERE`/`JOIN` conditions), limited to **`TOP 50` rows**.
- Purpose: sanity-check that the predicate is matching the right kind of rows — not a full blast-radius count. `TOP 50` will not reveal whether the true match set is 5,000 or 5,000,000 rows.
- **The dry-run query is AI-generated**, mechanically derived from the same predicate as the approved DML/DDL script (not hand-authored separately). Because it is generated code, it must be shown to the user and reviewed alongside the main script during Phase A — it is not exempt from review just because it's read-only, since a derivation error here could either mask or duplicate a bug in the real script.
- **Scale estimate — default is metadata-only, not a full scan:**
  - Default: get the SQL Server query optimizer's **estimated row count** for the real predicate (e.g. via `SET SHOWPLAN_XML ON` / `STATISTICS XML` without execution), which uses existing statistics and touches no data pages. Near-zero cost.
  - Optional, coarse fallback: total table row count via `sys.dm_db_partition_stats` (metadata-only, instant) — gives table size, not predicate-matched count, but useful context.
  - **True `COUNT_BIG(*)` with the real predicate is not run by default.** It performs a real scan/seek and can approach the cost of the write itself on large or poorly-indexed tables. It's available only as an explicit opt-in, flagged during impact analysis for cases where precision matters more than speed (e.g. small tables, or tables with a strong supporting index on the predicate).
- Runs outside any transaction — ordinary read locks only, no blocking of other sessions.

---

## 6. MCP Access Is Read-Only — Manual Execution Is the Only Write Path

The MCP connection used by the agent must be a **read-only tier**, enforced at two independent layers so neither one alone has to be fully trusted:

- **Package-level**: the MCP server itself should be a reader-tier build with no write-capable tools compiled in (e.g. no `insert_data`/`update_data`/`create_table`/`drop_table` in its tool list at all) — not a general-purpose server with a read-only *mode* that could be misconfigured or toggled.
- **Database-level**: the SQL login the MCP connection uses should hold only `SELECT`/`VIEW DEFINITION` grants, no `INSERT`/`UPDATE`/`DELETE`/`ALTER`/`CREATE`/`DROP`/`EXECUTE` beyond read-only SPs. This layer holds even if the MCP package layer has a bug or gap — it's enforced by the database engine itself, not by trusting a third-party package's tool list.

Because of this, **the agent has no mechanism to execute any write, ever** — this isn't a policy choice being self-enforced, it's a capability that doesn't exist on the connection. All DDL, DML, snapshot creation, and checkpoint-table writes are drafted by the agent as text and executed exclusively by the user, typically via SSMS or another client with a real, persistent session.

**What the read-only MCP connection is used for:**
- Schema study and cataloging (Section 1 in `02_DUNS_CLI_INSTRUCTIONS.md`)
- Dependency Discovery (Section 7) — live, real queries against `sys.*` catalog views
- The dry run (Section 5) — a genuine live `SELECT` using the real predicate, not a simulated/approximated one, since the connection can safely execute arbitrary `SELECT` text
- Pre-execution context gathering — current server/database name, snapshot existence checks, edition/feature support — all read-only
- Post-execution verification (Section 4a) — re-confirming the committed state matches what was approved

**Read-only queries are shown to the user, but not gated behind approval.** Since these queries can't write, they don't require the Phase A approval flow — but the actual SQL text being run should still be displayed as it executes, not hidden behind a summary. This is for the user's understanding and trust, not as a safety gate: seeing the real query (e.g. the exact dependency-discovery or row-count query) lets the user sanity-check the agent's reasoning and catch a misunderstanding early, well before it ever reaches a drafted write.

**What must hold true for every script the agent drafts** (regardless of the fact that only the user can run it):
- Explicitly transaction-wrapped with `XACT_ABORT ON`
- Batched per Section 3
- Accompanied by a tested/reviewed rollback script
- Preceded by the dry run and impact analysis, both already presented and approved
- Ends with `COMMIT`/`ROLLBACK` left for the user to type themselves, after reviewing the included verification output in their own session

The agent's responsibility ends at delivering a correct, complete, approved script bundle — it states this explicitly rather than implying it will also execute or hold open any part of it.

---

## 7. Dependency Discovery Procedure

For any table involved in a DUNS-related change (most commonly: adding a `new_DUNS` column and migrating data from the original DUNS column), run this fixed checklist during impact analysis, before any change is proposed for approval. This is a repeatable procedure applied per table, not custom-written per request.

1. **Indexes** on the column, including columns used only as `INCLUDE` (non-key) columns.
2. **Foreign keys**, checked in both directions — where the column is the referencing (child) column, and where it is the referenced (parent) column.
3. **Default constraints and check constraints** referencing the column (check constraint bodies require a text match against `sys.check_constraints.definition`, since they aren't linked to columns directly in metadata).
4. **Computed columns** whose definition references the column.
5. **Views, stored procedures, functions, and triggers** with a structural dependency on the column, via `sys.sql_expression_dependencies`. Where `referenced_minor_name` is unresolved (common with `SELECT *`), flag as "possible dependency — unresolved" for manual review rather than clearing it.
6. **Triggers**, checked explicitly against `sys.triggers`/`sys.sql_modules`, since trigger logic isn't always fully surfaced by the dependency view above.
7. **Dynamic SQL blind spot** — run a text-search fallback across all module definitions (`sys.sql_modules.definition LIKE '%COLUMN_NAME%'`) to catch references inside `EXEC(@sql)` / `sp_executesql` calls that static dependency views cannot see. Treat matches as "needs manual review — possible dynamic SQL reference," not as automatically safe or unsafe.
8. **Synonyms, replication, and Change Data Capture (CDC)** — check for synonyms pointing at the table, and whether the table is under CDC or transactional replication, since either changes what a column addition/migration requires downstream.

All eight checks are logged into the impact analysis report for that table, before the change is eligible for Phase A approval.

---

## 8. Stored Procedure Updates

- Run the Dependency Discovery Procedure (Section 7) against any SP flagged as referencing the affected table/column, and list potential breaking changes explicitly.
- An offer to test-execute an SP after commit only applies to **read-only/validation SPs**. Any SP with write potential must go through the same Phase A/B approval flow as any other write — it is never auto-executed as a "quick post-commit check."

---

## 9. DDL-Specific Constraint

- Explicitly warn about **Schema Modification (Sch-M) locks** before proposing any `ALTER TABLE`, since this blocks all readers and writers on the table for the duration of the change.
- For tables above a size/row-count threshold (to be set in config), flag the change as requiring a maintenance window rather than a live-hours change.

## 10. Rollback Script — Scope Note

A rollback script (Section 4, Phase A) is a **post-commit corrective action**, not the same mechanism as `ROLLBACK TRANSACTION`. It applies to any approved write — DDL or DML — but its risk and complexity are not uniform across the migration lifecycle (see `03_DUNS_MIGRATION_LIFECYCLE.md`):

- Early-stage changes (adding a new column, migrating data into it) are cheap to reverse by design, since the original column is never touched — reverting typically means clearing or dropping only the new column.
- Later-stage changes carry progressively more risk to reverse cleanly, since more of the system may already depend on the change. Detailed guidance for those later stages is deferred until they're actually being planned.

## 11. Workspace & File Layout

```
.duns-cli/
├── config/
│   └── duns-cli.config.yaml
│
├── schema-cache/
│   └── schema-snapshot_<YYYYMMDD_HHMMSS>.json     # persisted, human-readable schema copy (Section 1)
│
├── plans/
│   └── <plan-id>.json                              # Phase A approved plan record
│
├── rollback/
│   └── <plan-id>_rollback.sql                      # reviewed alongside the plan in Phase A
│
├── checkpoints/
│   └── <plan-id>_<table>.json                      # local mirror of DB checkpoint + failures (Section 3a)
│
├── logs/
│   └── <plan-id>_<YYYYMMDD_HHMMSS>.log              # script bundle + outcome + agent's post-execution verification (Section 4)
│
└── audit/
    └── audit.log                                    # append-only: every read/plan/approve/apply
```

Database-side (tool-owned schema, separate from client business tables):

```
duns_cli.migration_checkpoint     -- source of truth for in-progress data migrations (Section 3a)
<table>_bkt                        -- per-table backup copy, required before DUNS expansion (Section 4c)
```

## 12. Production Query Discipline

The target database is a live production system, not a sandbox. This constrains how every query is written — read-only investigative queries included, not just drafted writes — since even a read can degrade production performance if written carelessly.

- **Row counts always come from metadata, never `COUNT(*)`.** Per `02_DUNS_CLI_INSTRUCTIONS.md` Section 1, use `sys.partitions` / `sys.dm_db_partition_stats` for cataloging-level counts. This is the default, cheapest, and correct way to answer "how many rows does this table have" — a full scan is never the first choice, and is only used as an explicit, deliberate opt-in (Section 5) when a specific, real number is genuinely required.
- **Prefer indexed predicates.** Any query the agent drafts — read-only or write — should be checked against existing indexes before being proposed. If a predicate isn't indexed and the table is large, that's worth surfacing to the user as a finding in its own right (a candidate for an index, or a signal the operation needs a maintenance window), not just executed as-is.
- **Avoid `SELECT *`** in investigative queries where specific columns are all that's needed — smaller result sets, less I/O, less network transfer, especially relevant on wide tables.
- **Sample rather than scan** wherever a full result set isn't actually needed — `TOP N` for eyeballing shape, estimated-plan row counts (Section 5) for scale, rather than pulling full result sets for exploratory purposes.
- **Time-bound investigative queries** where the tool supports it — a `LOCK_TIMEOUT` or query timeout on read-only exploration queries prevents an unexpectedly expensive query from sitting and consuming resources indefinitely on a live system.
- **This applies to every phase equally** — schema cataloging (Section 1), Dependency Discovery (Section 7), the dry run (Section 5), and post-execution verification (Section 4a) are all real queries against a real production system and are held to the same discipline, not just the eventual write.
